import { ref, onMounted, mergeProps, unref, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual, ssrRenderList } from "vue/server-renderer";
import { useForm } from "@inertiajs/vue3";
import { _ as _sfc_main$1, a as _sfc_main$2 } from "./Sidebar-471d4597.js";
import { F as Footer } from "./Footer-7a30cc67.js";
import axios from "axios";
import "./_plugin-vue_export-helper-cc2b3d55.js";
Swal.mixin({
  customClass: {
    confirmButton: "btn btn-danger",
    cancelButton: "btn btn-secondary"
  },
  buttonsStyling: false
});
const _sfc_main = {
  __name: "Staff",
  __ssrInlineRender: true,
  props: {
    staff: Array,
    auth: Array
  },
  setup(__props) {
    const successToast = ref(null);
    const label = useForm({ response: null });
    const createModal = ref(null);
    const editModal = ref(null);
    onMounted(() => {
      createModal.value = new bootstrap.Modal($("#createModal"), {
        keyboard: false
      });
      editModal.value = new bootstrap.Modal($("#editModal"), {
        keyboard: false
      });
      successToast.value = new bootstrap.Toast($("#success-toast"), {
        keyboard: false
      });
      fetchRegions();
    });
    const createForm = useForm({
      firstname: null,
      lastname: null,
      middlename: null,
      suffix: null,
      position: null,
      region: null,
      province: null,
      municipal: null,
      barangay: null,
      email: null,
      contactNumber: null,
      password: null,
      error: null,
      status: null
    });
    const regions = ref([]);
    const provinces = ref([]);
    const municipals = ref([]);
    const barangays = ref([]);
    const fetchRegions = async () => {
      try {
        const response = await axios.get("/admin/regions");
        regions.value = response.data;
      } catch (error) {
        console.error("Error fetching regions:", error);
      }
    };
    const editForm = useForm({
      id: null,
      firstname: null,
      lastname: null,
      middlename: null,
      suffix: null,
      position: null,
      region: null,
      province: null,
      municipal: null,
      barangay: null,
      email: null,
      contactNumber: null,
      password: null,
      error: null,
      status: null
    });
    function capitalizeWords(text) {
      if (!text)
        return "";
      return text.toLowerCase().replace(/\b\w/g, (char) => char.toUpperCase());
    }
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "wrapper" }, _attrs))}>`);
      _push(ssrRenderComponent(_sfc_main$1, { page: "Staff & Personnel" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, null, null, _parent));
      _push(`<div class="toast-container position-fixed top-0 start-50 translate-middle-x p-4"><div id="success-toast" class="toast" role="alert" aria-live="assertive" aria-atomic="true"><div class="toast-header"><div class="auth-logo me-auto"><span class="fs-4 fw-bold"> Done </span></div><small class="text-success fs-4"><i class="fa-solid fa-circle-check"></i></small><button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button></div><div class="toast-body">${ssrInterpolate(unref(label).response)}</div></div></div><div class="modal fade" id="createModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true"><div class="modal-dialog modal-lg"><div class="modal-content"><div class="modal-header"><h5 class="modal-title" id="staticBackdropLabel">Create Staff</h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><form action=""><div class="modal-body">`);
      if (unref(createForm).error) {
        _push(`<div class="alert alert-danger">${ssrInterpolate(unref(createForm).error)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="row"><div class="col-md-3"><label for="" class="mb-1">First Name</label><input type="text" class="form-control mb-3"${ssrRenderAttr("value", unref(createForm).firstname)} required></div><div class="col-md-3"><label for="" class="mb-1">Middle Name</label><input type="text" class="form-control mb-3"${ssrRenderAttr("value", unref(createForm).middlename)}></div><div class="col-md-3"><label for="" class="mb-1">Last Name</label><input type="text" class="form-control mb-3"${ssrRenderAttr("value", unref(createForm).lastname)} required></div><div class="col-md-3"><label for="" class="mb-1">Suffix</label><input type="text" class="form-control mb-3"${ssrRenderAttr("value", unref(createForm).suffix)}></div></div><div class="row"><div class="col-md-6"><label for="" class="mb-1">Position</label><select name="" id="" class="form-select mb-3" required><option value="STMG Enforcer"${ssrIncludeBooleanAttr(Array.isArray(unref(createForm).position) ? ssrLooseContain(unref(createForm).position, "STMG Enforcer") : ssrLooseEqual(unref(createForm).position, "STMG Enforcer")) ? " selected" : ""}>STMG Enforcer</option><option value="Traffic Enforcer"${ssrIncludeBooleanAttr(Array.isArray(unref(createForm).position) ? ssrLooseContain(unref(createForm).position, "Traffic Enforcer") : ssrLooseEqual(unref(createForm).position, "Traffic Enforcer")) ? " selected" : ""}>Traffic Enforcer</option></select></div><div class="col-md-6"><label for="" class="mb-1">Contact Number</label><input type="number" class="form-control mb-3"${ssrRenderAttr("value", unref(createForm).contactNumber)} required></div></div><div class="row"><div class="col-md-6"><label for="region" class="mb-1">Region</label><select class="form-select mb-3" required><option value="" disabled${ssrIncludeBooleanAttr(Array.isArray(unref(createForm).region) ? ssrLooseContain(unref(createForm).region, "") : ssrLooseEqual(unref(createForm).region, "")) ? " selected" : ""}>Select a Region</option><!--[-->`);
      ssrRenderList(regions.value, (region) => {
        _push(`<option${ssrRenderAttr("value", region.regCode)}>${ssrInterpolate(region.regDesc)}</option>`);
      });
      _push(`<!--]--></select></div><div class="col-md-6"><label for="province" class="mb-1">Province</label><select class="form-select mb-3" required><option value="" disabled${ssrIncludeBooleanAttr(Array.isArray(unref(createForm).province) ? ssrLooseContain(unref(createForm).province, "") : ssrLooseEqual(unref(createForm).province, "")) ? " selected" : ""}>Select a Province</option><!--[-->`);
      ssrRenderList(provinces.value, (province) => {
        _push(`<option${ssrRenderAttr("value", province.provCode)}>${ssrInterpolate(province.provDesc)}</option>`);
      });
      _push(`<!--]--></select></div></div><div class="row"><div class="col-md-6"><label for="municipal" class="mb-1">Municipal</label><select class="form-select mb-3" required><option value="" disabled${ssrIncludeBooleanAttr(Array.isArray(unref(createForm).municipal) ? ssrLooseContain(unref(createForm).municipal, "") : ssrLooseEqual(unref(createForm).municipal, "")) ? " selected" : ""}>Select a Municipal</option><!--[-->`);
      ssrRenderList(municipals.value, (municipal) => {
        _push(`<option${ssrRenderAttr("value", municipal.citymunCode)}>${ssrInterpolate(municipal.citymunDesc)}</option>`);
      });
      _push(`<!--]--></select></div><div class="col-md-6"><label for="barangay" class="mb-1">Barangay</label><select class="form-select mb-3" required><option value="" disabled${ssrIncludeBooleanAttr(Array.isArray(unref(createForm).barangay) ? ssrLooseContain(unref(createForm).barangay, "") : ssrLooseEqual(unref(createForm).barangay, "")) ? " selected" : ""}>Select a Barangay</option><!--[-->`);
      ssrRenderList(barangays.value, (barangay) => {
        _push(`<option${ssrRenderAttr("value", barangay.brgyCode)}>${ssrInterpolate(barangay.brgyDesc)}</option>`);
      });
      _push(`<!--]--></select></div></div><label for="" class="mb-1">Email</label><input type="email" class="form-control mb-3"${ssrRenderAttr("value", unref(createForm).email)} required><label for="" class="mb-1">Password</label><input type="password" class="form-control"${ssrRenderAttr("value", unref(createForm).password)} required></div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button><button type="" class="btn btn-primary">Save</button></div></form></div></div></div><div class="modal fade" id="editModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true"><div class="modal-dialog modal-lg"><div class="modal-content"><div class="modal-header"><h5 class="modal-title" id="staticBackdropLabel">Edit User</h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><form action=""><div class="modal-body">`);
      if (unref(editForm).error) {
        _push(`<div class="alert alert-danger">${ssrInterpolate(unref(editForm).error)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<input type="hidden" class="form-control"${ssrRenderAttr("value", unref(editForm).id)}><div class="row"><div class="col-md-3"><label for="" class="mb-1">First Name</label><input type="text" class="form-control mb-3"${ssrRenderAttr("value", unref(editForm).firstname)} required></div><div class="col-md-3"><label for="" class="mb-1">Middle Name</label><input type="text" class="form-control mb-3"${ssrRenderAttr("value", unref(editForm).middlename)}></div><div class="col-md-3"><label for="" class="mb-1">Last Name</label><input type="text" class="form-control mb-3"${ssrRenderAttr("value", unref(editForm).lastname)} required></div><div class="col-md-3"><label for="" class="mb-1">Suffix</label><input type="text" class="form-control mb-3"${ssrRenderAttr("value", unref(editForm).suffix)}></div></div><div class="row"><div class="col-md-6"><label for="" class="mb-1">Position</label><select name="" id="" class="form-select mb-3" required><option value="STMG Enforcer"${ssrIncludeBooleanAttr(Array.isArray(unref(editForm).position) ? ssrLooseContain(unref(editForm).position, "STMG Enforcer") : ssrLooseEqual(unref(editForm).position, "STMG Enforcer")) ? " selected" : ""}>STMG Enforcer</option><option value="Traffic Enforcer"${ssrIncludeBooleanAttr(Array.isArray(unref(editForm).position) ? ssrLooseContain(unref(editForm).position, "Traffic Enforcer") : ssrLooseEqual(unref(editForm).position, "Traffic Enforcer")) ? " selected" : ""}>Traffic Enforcer</option></select></div><div class="col-md-6"><label for="" class="mb-1">Contact Number</label><input type="number" class="form-control mb-3"${ssrRenderAttr("value", unref(editForm).contactNumber)} required></div></div><div class="row"><div class="col-md-6"><label for="region" class="mb-1">Region</label><select class="form-select mb-3" required><option value="" disabled${ssrIncludeBooleanAttr(Array.isArray(unref(editForm).region) ? ssrLooseContain(unref(editForm).region, "") : ssrLooseEqual(unref(editForm).region, "")) ? " selected" : ""}>Select a Region</option><!--[-->`);
      ssrRenderList(regions.value, (region) => {
        _push(`<option${ssrRenderAttr("value", region.regCode)}>${ssrInterpolate(region.regDesc)}</option>`);
      });
      _push(`<!--]--></select></div><div class="col-md-6"><label for="province" class="mb-1">Province</label><select class="form-select mb-3" required><option value="" disabled${ssrIncludeBooleanAttr(Array.isArray(unref(editForm).province) ? ssrLooseContain(unref(editForm).province, "") : ssrLooseEqual(unref(editForm).province, "")) ? " selected" : ""}>Select a Province</option><!--[-->`);
      ssrRenderList(provinces.value, (province) => {
        _push(`<option${ssrRenderAttr("value", province.provCode)}>${ssrInterpolate(province.provDesc)}</option>`);
      });
      _push(`<!--]--></select></div></div><div class="row"><div class="col-md-6"><label for="municipal" class="mb-1">Municipal</label><select class="form-select mb-3" required><option value="" disabled${ssrIncludeBooleanAttr(Array.isArray(unref(editForm).municipal) ? ssrLooseContain(unref(editForm).municipal, "") : ssrLooseEqual(unref(editForm).municipal, "")) ? " selected" : ""}>Select a Municipal</option><!--[-->`);
      ssrRenderList(municipals.value, (municipal) => {
        _push(`<option${ssrRenderAttr("value", municipal.citymunCode)}>${ssrInterpolate(municipal.citymunDesc)}</option>`);
      });
      _push(`<!--]--></select></div><div class="col-md-6"><label for="barangay" class="mb-1">Barangay</label><select class="form-select mb-3" required><option value="" disabled${ssrIncludeBooleanAttr(Array.isArray(unref(editForm).barangay) ? ssrLooseContain(unref(editForm).barangay, "") : ssrLooseEqual(unref(editForm).barangay, "")) ? " selected" : ""}>Select a Barangay</option><!--[-->`);
      ssrRenderList(barangays.value, (barangay) => {
        _push(`<option${ssrRenderAttr("value", barangay.brgyCode)}>${ssrInterpolate(barangay.brgyDesc)}</option>`);
      });
      _push(`<!--]--></select></div></div><label for="" class="mb-1">Email</label><input type="email" class="form-control mb-3"${ssrRenderAttr("value", unref(editForm).email)} required><label for="" class="mb-1">Change Password</label><input type="password" class="form-control"${ssrRenderAttr("value", unref(editForm).password)}></div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button><button type="" class="btn btn-primary">Save</button></div></form></div></div></div><div class="page-content"><div class="container-fluid"><div class="row"><div class="col-md-12"><div class="card"><div class="card-header"><div class="d-flex justify-content-between align-items-center"><h6 class="fw-bold">List of Staffs</h6><button class="btn btn-primary shadow-lg btn-sm"> + Add</button></div></div><div class="card-body"><div class="table-responsive"><table class="table table-hover text-nowrap"><thead><tr class="fs-6"><th>No.</th><th>Name</th><th>Position</th><th>Address</th><th>Action</th></tr></thead><tbody><!--[-->`);
      ssrRenderList(__props.staff, (st, index) => {
        _push(`<tr><td>${ssrInterpolate(index + 1)}</td><td>${ssrInterpolate(st.firstname)} ${ssrInterpolate(st.middlename)} ${ssrInterpolate(st.lastname)} ${ssrInterpolate(st.suffix ? `. ${st.suffix}` : "")}</td><td>${ssrInterpolate(st.position)}</td><td> Brgy. ${ssrInterpolate(st.barangay != null ? st.barangay.brgyDesc : "")} ${ssrInterpolate(st.municipal != null ? capitalizeWords(st.municipal.citymunDesc) : "")} ${ssrInterpolate(st.province != null ? capitalizeWords(st.province.provDesc) : "")}</td><td><a href="#" class="me-2"><i class="fa-solid fa-pencil"></i></a><a href="#" class=""><i class="fa-solid fa-trash"></i></a></td></tr>`);
      });
      _push(`<!--]--></tbody></table></div></div></div></div></div></div>`);
      _push(ssrRenderComponent(Footer, null, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Staff.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
