import { useSSRContext, ref, onMounted, resolveComponent, unref, mergeProps } from "vue";
import { ssrInterpolate, ssrRenderAttr, ssrRenderComponent, ssrRenderAttrs, ssrRenderStyle, ssrRenderClass } from "vue/server-renderer";
import { useForm, usePage } from "@inertiajs/vue3";
const __default__$1 = {
  methods: {
    logout() {
      this.$inertia.get(route("logout"));
    }
  }
};
const _sfc_main$1 = /* @__PURE__ */ Object.assign(__default__$1, {
  __name: "Navbar",
  __ssrInlineRender: true,
  props: {
    page: String
  },
  setup(__props) {
    const user = ref(null);
    const profileSuccessToast = ref(null);
    const profileLabel = useForm({ response: null });
    const editProfileModal = ref(null);
    onMounted(() => {
      const page = usePage();
      user.value = page.props.auth;
      editProfileModal.value = new bootstrap.Modal($("#editProfileModal"), {
        keyboard: false
      });
      profileSuccessToast.value = new bootstrap.Toast($("#profile-success-toast"), {
        keyboard: false
      });
    });
    const editProfileForm = useForm({
      name: null,
      firstname: null,
      middlename: null,
      lastname: null,
      suffix: null,
      email: null,
      password: null,
      error: null
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o;
      const _component_iconify_icon = resolveComponent("iconify-icon");
      _push(`<!--[--><div class="toast-container position-fixed top-0 start-50 translate-middle-x p-4"><div id="profile-success-toast" class="toast" role="alert" aria-live="assertive" aria-atomic="true"><div class="toast-header"><div class="auth-logo me-auto"><span class="fs-4 fw-bold"> Done </span></div><small class="text-success fs-4"><i class="fa-solid fa-circle-check"></i></small><button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button></div><div class="toast-body">${ssrInterpolate(unref(profileLabel).response)}</div></div></div><div class="modal fade" id="editProfileModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><h5 class="modal-title" id="staticBackdropLabel">Edit Profile</h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><form action=""><div class="modal-body">`);
      if (unref(editProfileForm).error) {
        _push(`<div class="alert alert-danger">${ssrInterpolate(unref(editProfileForm).error)}</div>`);
      } else {
        _push(`<!---->`);
      }
      if (((_a = user.value) == null ? void 0 : _a.role) == 1) {
        _push(`<div><label for="" class="mb-1">Full Name</label><input type="text" class="form-control mb-3"${ssrRenderAttr("value", unref(editProfileForm).name)} required></div>`);
      } else {
        _push(`<!---->`);
      }
      if (((_b = user.value) == null ? void 0 : _b.role) == 2) {
        _push(`<div><label for="" class="mb-1">First Name</label><input type="text" class="form-control mb-3"${ssrRenderAttr("value", unref(editProfileForm).firstname)} required><label for="" class="mb-1">Middle Name</label><input type="text" class="form-control mb-3"${ssrRenderAttr("value", unref(editProfileForm).middlename)}><label for="" class="mb-1">Last Name</label><input type="text" class="form-control mb-3"${ssrRenderAttr("value", unref(editProfileForm).lastname)} required><label for="" class="mb-1">Suffix</label><input type="text" class="form-control mb-3"${ssrRenderAttr("value", unref(editProfileForm).suffix)}></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<label for="" class="mb-1">Email</label><input type="email" class="form-control mb-3"${ssrRenderAttr("value", unref(editProfileForm).email)} required><label for="" class="mb-1">Change Password</label><input type="password" class="form-control"${ssrRenderAttr("value", unref(editProfileForm).password)}></div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button><button type="" class="btn btn-primary">Save</button></div></form></div></div></div><header class="topbar"><div class="container-fluid"><div class="navbar-header"><div class="d-flex align-items-center gap-2"><div class="topbar-item"><button type="button" class="button-toggle-menu">`);
      _push(ssrRenderComponent(_component_iconify_icon, {
        icon: "solar:hamburger-menu-broken",
        class: "fs-24 align-middle"
      }, null, _parent));
      _push(`</button></div><form class="app-search d-none d-md-block me-auto"><div class="position-relative fw-bold">${ssrInterpolate(__props.page)}</div></form></div><div class="d-flex align-items-center gap-1"><div class="dropdown topbar-item"><a type="button" class="topbar-button" id="page-header-user-dropdown" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="d-flex align-items-center">`);
      if (((_c = user.value) == null ? void 0 : _c.role) === 1) {
        _push(`<span class="me-2 fw-bold">${ssrInterpolate((_d = user.value) == null ? void 0 : _d.name)}</span>`);
      } else {
        _push(`<!---->`);
      }
      if (((_e = user.value) == null ? void 0 : _e.role) === 2) {
        _push(`<span class="me-2 fw-bold">${ssrInterpolate((_f = user.value) == null ? void 0 : _f.staff.firstname)} ${ssrInterpolate((_g = user.value) == null ? void 0 : _g.staff.middename)} ${ssrInterpolate((_h = user.value) == null ? void 0 : _h.staff.lastname)} ${ssrInterpolate((_i = user.value) == null ? void 0 : _i.staff.suffix)}</span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<img class="rounded-circle" width="32" src="/logo/office-man.png" alt="avatar-3"></span></a><div class="dropdown-menu">`);
      if (((_j = user.value) == null ? void 0 : _j.role) === 1) {
        _push(`<h6 class="dropdown-header fw-bold">${ssrInterpolate((_k = user.value) == null ? void 0 : _k.name)}</h6>`);
      } else {
        _push(`<!---->`);
      }
      if (((_l = user.value) == null ? void 0 : _l.role) === 2) {
        _push(`<h6 class="dropdown-header fw-bold">${ssrInterpolate((_m = user.value) == null ? void 0 : _m.staff.name)}</h6>`);
      } else {
        _push(`<!---->`);
      }
      if (((_n = user.value) == null ? void 0 : _n.role) === 1) {
        _push(`<a href="" class="dropdown-item">`);
        _push(ssrRenderComponent(_component_iconify_icon, {
          icon: "solar:user-bold-duotone",
          class: "align-middle me-2 fs-18"
        }, null, _parent));
        _push(`<span class="align-middle text-dark">My Account</span></a>`);
      } else {
        _push(`<!---->`);
      }
      if (((_o = user.value) == null ? void 0 : _o.role) === 2) {
        _push(`<a href="" class="dropdown-item">`);
        _push(ssrRenderComponent(_component_iconify_icon, {
          icon: "solar:user-bold-duotone",
          class: "align-middle me-2 fs-18"
        }, null, _parent));
        _push(`<span class="align-middle text-dark">My Account</span></a>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<hr><a href="" class="dropdown-item text-danger">`);
      _push(ssrRenderComponent(_component_iconify_icon, {
        icon: "solar:logout-3-bold-duotone",
        class: "align-middle me-2 fs-18"
      }, null, _parent));
      _push(`<span class="align-middle text-dark">Logout</span></a></div></div></div></div></div></header><!--]-->`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Layouts/Navbar.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
function checkWindowSize() {
  if ($(window).width() < 576) {
    $("html").attr("data-menu-size", "hidden");
  } else {
    $("html").removeAttr("data-menu-size");
    $(".page-content").show();
  }
}
$(document).ready(function() {
  checkWindowSize();
  $(window).resize(checkWindowSize);
  $(document).on("click", ".button-toggle-menu", function() {
    const menuSize = $("html").attr("data-menu-size");
    if ($(window).width() < 576) {
      if (menuSize === "hidden") {
        $("html").removeAttr("data-menu-size");
        $(".page-content").hide(200);
      } else {
        $("html").attr("data-menu-size", "hidden");
        $(".page-content").show(200);
      }
    } else {
      if (menuSize === "hidden") {
        $("html").removeAttr("data-menu-size");
      } else {
        $("html").attr("data-menu-size", "hidden");
      }
    }
  });
});
const __default__ = {
  methods: {
    dashboard() {
      this.$inertia.get(route("dashboard"));
      checkWindowSize();
      $(window).resize(checkWindowSize);
    },
    sample() {
      this.$inertia.get(route("staff"));
      checkWindowSize();
      $(window).resize(checkWindowSize);
    },
    violation() {
      this.$inertia.get(route("violation"));
      checkWindowSize();
      $(window).resize(checkWindowSize);
    },
    drivers() {
      this.$inertia.get(route("drivers"));
      checkWindowSize();
      $(window).resize(checkWindowSize);
    },
    receiptInfo() {
      this.$inertia.get(route("receipt-info"));
      checkWindowSize();
      $(window).resize(checkWindowSize);
    },
    ticketHistory() {
      this.$inertia.get(route("user.ticket-history"));
      checkWindowSize();
      $(window).resize(checkWindowSize);
    },
    isDashboardActive() {
      return this.$page.component === "Admin/Dashboard" || this.$page.component === "User/Dashboard";
    },
    isStaffActive() {
      return this.$page.component === "Admin/Staff";
    },
    isViolationActive() {
      return this.$page.component === "Admin/Violation";
    },
    isDriversActive() {
      return this.$page.component === "Admin/Drivers";
    },
    isReceiptInfoActive() {
      return this.$page.component === "Admin/ReceiptInfo";
    },
    isTicketHistoryActive() {
      return this.$page.component === "User/Ticket-History";
    }
  }
};
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  __name: "Sidebar",
  __ssrInlineRender: true,
  setup(__props) {
    const user = ref(null);
    onMounted(() => {
      const page = usePage();
      user.value = page.props.auth;
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b;
      const _component_iconify_icon = resolveComponent("iconify-icon");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "main-nav" }, _attrs))}><div class="logo-box mt-3 mb-3 d-flex align-items-center justify-content-between"><div class="d-flex align-items-center"><a href="#" class="logo-dark d-flex align-items-center"><img src="/logo/stmg-2.png" class="logo-xl" alt="logo dark" style="${ssrRenderStyle({ "width": "150px" })}"></a></div></div><div class="scrollbar" data-simplebar><ul class="navbar-nav" id="navbar-nav"><hr><li class="menu-title">Menu</li>`);
      if (((_a = user.value) == null ? void 0 : _a.role) === 1) {
        _push(`<div><li class="nav-item"><a href="" class="${ssrRenderClass(["nav-link", _ctx.isDashboardActive() ? "active" : ""])}" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarDashboards"><span class="nav-icon">`);
        _push(ssrRenderComponent(_component_iconify_icon, {
          icon: "solar:chart-bold-duotone",
          width: "24",
          height: "24"
        }, null, _parent));
        _push(`</span><span class="nav-text" style="${ssrRenderStyle({ "font-size": "14px" })}"> Dashboard </span></a></li><li class="nav-item"><a href="" class="${ssrRenderClass(["nav-link", _ctx.isStaffActive() ? "active" : ""])}" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarSample"><span class="nav-icon">`);
        _push(ssrRenderComponent(_component_iconify_icon, {
          icon: "solar:users-group-rounded-bold-duotone",
          width: "24",
          height: "24"
        }, null, _parent));
        _push(`</span><span class="nav-text" style="${ssrRenderStyle({ "font-size": "14px" })}"> Staff </span></a></li><li class="nav-item"><a href="" class="${ssrRenderClass(["nav-link", _ctx.isViolationActive() ? "active" : ""])}" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarSample"><span class="nav-icon">`);
        _push(ssrRenderComponent(_component_iconify_icon, {
          icon: "solar:pin-list-bold-duotone",
          width: "24",
          height: "24"
        }, null, _parent));
        _push(`</span><span class="nav-text" style="${ssrRenderStyle({ "font-size": "14px" })}"> Violations </span></a></li><li class="nav-item"><a href="" class="${ssrRenderClass(["nav-link", _ctx.isDriversActive() ? "active" : ""])}" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarSample"><span class="nav-icon">`);
        _push(ssrRenderComponent(_component_iconify_icon, {
          icon: "fluent:chart-person-20-filled",
          width: "24",
          height: "24"
        }, null, _parent));
        _push(`</span><span class="nav-text" style="${ssrRenderStyle({ "font-size": "14px" })}"> Driver Records </span></a></li></div>`);
      } else {
        _push(`<!---->`);
      }
      if (((_b = user.value) == null ? void 0 : _b.role) === 2) {
        _push(`<div><li class="nav-item"><a href="" class="${ssrRenderClass(["nav-link", _ctx.isDashboardActive() ? "active" : ""])}" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarDashboards"><span class="nav-icon">`);
        _push(ssrRenderComponent(_component_iconify_icon, {
          icon: "solar:screencast-bold-duotone",
          width: "24",
          height: "24"
        }, null, _parent));
        _push(`</span><span class="nav-text" style="${ssrRenderStyle({ "font-size": "14px" })}"> Dashboard </span></a></li><li class="nav-item"><a href="" class="${ssrRenderClass(["nav-link", _ctx.isTicketHistoryActive() ? "active" : ""])}" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarDashboards"><span class="nav-icon">`);
        _push(ssrRenderComponent(_component_iconify_icon, {
          icon: "streamline:ticket-1-solid",
          width: "20",
          height: "20"
        }, null, _parent));
        _push(`</span><span class="nav-text" style="${ssrRenderStyle({ "font-size": "14px" })}"> Ticket History </span></a></li></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</ul></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Layouts/Sidebar.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main$1 as _,
  _sfc_main as a
};
