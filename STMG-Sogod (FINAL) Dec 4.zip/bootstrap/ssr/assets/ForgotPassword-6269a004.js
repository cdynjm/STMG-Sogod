import { resolveComponent, mergeProps, withCtx, createVNode, useSSRContext } from "vue";
import { useForm } from "@inertiajs/vue3";
import "./Footer-7a30cc67.js";
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderStyle, ssrInterpolate, ssrRenderAttr } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.js";
const _sfc_main = {
  setup() {
    const form = useForm({
      email: "",
      error: null,
      success: null
    });
    const submit = () => {
      form.error = null;
      form.success = null;
      form.post(route("password.email"), {
        onSuccess: (page) => {
          form.success = "A reset link has been sent to your email address.";
        },
        onError: (errors) => {
          form.error = errors.email;
        }
      });
    };
    return { form, submit };
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_center = resolveComponent("center");
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "account-pages pt-2 pt-sm-5 pb-4 pb-sm-5" }, _attrs))}><div class="container"><div class="row justify-content-center"><div class="col-xl-5"><div class="card auth-card shadow-lg"><div class="card-body px-3 py-5"><div class="mb-4 text-center auth-logo"><a href="#" class="logo-dark">`);
  _push(ssrRenderComponent(_component_center, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<img src="/logo/stmg-2.png" class="me-2" style="${ssrRenderStyle({ "width": "160px" })}" alt="logo dark"${_scopeId}><div class="fw-bold mt-2"${_scopeId}>STMG-Road Traffic Offense IMS</div>`);
      } else {
        return [
          createVNode("img", {
            src: "/logo/stmg-2.png",
            class: "me-2",
            style: { "width": "160px" },
            alt: "logo dark"
          }),
          createVNode("div", { class: "fw-bold mt-2" }, "STMG-Road Traffic Offense IMS")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</a></div><h2 class="fw-bold text-uppercase text-center fs-18">Forgot Password</h2><p class="text-muted text-center mt-1 mb-4">Enter your email address to reset your password</p><div class="px-4">`);
  if ($setup.form.error) {
    _push(`<div class="alert alert-danger">${ssrInterpolate($setup.form.error)}</div>`);
  } else {
    _push(`<!---->`);
  }
  if ($setup.form.success) {
    _push(`<div class="alert alert-success">${ssrInterpolate($setup.form.success)}</div>`);
  } else {
    _push(`<!---->`);
  }
  _push(`<form><div><label for="email">Email</label><input type="email" class="form-control form-control-sm mb-3"${ssrRenderAttr("value", $setup.form.email)} required autofocus></div><div><button type="submit" class="btn btn-sm btn-primary">Send Password Reset Link</button></div></form></div></div></div></div></div></div></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Auth/ForgotPassword.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const ForgotPassword = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  ForgotPassword as default
};
