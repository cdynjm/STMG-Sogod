import { resolveComponent, mergeProps, withCtx, createVNode, useSSRContext } from "vue";
import { useForm } from "@inertiajs/vue3";
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderStyle, ssrInterpolate, ssrRenderAttr } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.js";
const _sfc_main = {
  props: {
    token: String,
    email: String
  },
  setup(props) {
    const form = useForm({
      token: props.token,
      email: props.email || "",
      password: "",
      password_confirmation: "",
      error: null,
      success: null
    });
    const submit = () => {
      form.post(route("password.update"), {
        onError: (errors) => {
          form.error = "Password did not match.";
        }
      });
    };
    return { form, submit };
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_center = resolveComponent("center");
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "account-pages pt-2 pt-sm-5 pb-4 pb-sm-5" }, _attrs))}><div class="container"><div class="row justify-content-center"><div class="col-xl-5"><div class="card auth-card shadow-lg"><div class="card-body px-3 py-5"><div class="mb-4 text-center auth-logo"><a href="#" class="logo-dark">`);
  _push(ssrRenderComponent(_component_center, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<img src="/logo/stmg-2.png" class="me-2" style="${ssrRenderStyle({ "width": "160px" })}" alt="logo dark"${_scopeId}><div class="fw-bold mt-2"${_scopeId}>STMG-Road Traffic Offense IMS</div>`);
      } else {
        return [
          createVNode("img", {
            src: "/logo/stmg-2.png",
            class: "me-2",
            style: { "width": "160px" },
            alt: "logo dark"
          }),
          createVNode("div", { class: "fw-bold mt-2" }, "STMG-Road Traffic Offense IMS")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</a></div><h2 class="fw-bold text-uppercase text-center fs-18">Reset Password</h2><p class="text-muted text-center mt-1 mb-4">Create new password</p><div class="px-4">`);
  if ($setup.form.error) {
    _push(`<div class="alert alert-danger">${ssrInterpolate($setup.form.error)}</div>`);
  } else {
    _push(`<!---->`);
  }
  _push(`<form><input type="hidden"${ssrRenderAttr("value", $setup.form.token)}><div><label for="email">Email</label><input type="email" class="form-control form-control-sm mb-3"${ssrRenderAttr("value", $setup.form.email)} readonly></div><div><label for="password">Password</label><input type="password" class="form-control form-control-sm mb-3"${ssrRenderAttr("value", $setup.form.password)} required></div><div><label for="password_confirmation">Confirm Password</label><input type="password" class="form-control form-control-sm mb-3"${ssrRenderAttr("value", $setup.form.password_confirmation)} required></div><div><button type="submit" class="btn btn-sm btn-primary">Reset Password</button></div></form></div></div></div></div></div></div></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Auth/ResetPassword.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const ResetPassword = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  ResetPassword as default
};
