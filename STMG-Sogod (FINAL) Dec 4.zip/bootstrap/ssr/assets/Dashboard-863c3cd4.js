import { ref, watch, onMounted, resolveComponent, mergeProps, unref, withCtx, createVNode, toDisplayString, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderAttr } from "vue/server-renderer";
import "vue3-apexcharts";
import { useForm, Link } from "@inertiajs/vue3";
import { _ as _sfc_main$1, a as _sfc_main$2 } from "./Sidebar-471d4597.js";
import { F as Footer } from "./Footer-7a30cc67.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
const Dashboard_vue_vue_type_style_index_0_lang = "";
const _sfc_main = {
  __name: "Dashboard",
  __ssrInlineRender: true,
  props: {
    auth: Array,
    unpaid: Number,
    vehicle: Array,
    vehicleCount: Number,
    violation: Array,
    violationList: Array,
    topViolations: Object,
    year: String,
    driver: Array
  },
  setup(__props) {
    const props = __props;
    const searchForm = useForm({
      search: null,
      result: 0
    });
    const currentYear = (/* @__PURE__ */ new Date()).getFullYear();
    const startYear = 2020;
    const years = Array.from({ length: currentYear - startYear + 1 }, (_, i) => startYear + i);
    const month = Array(12).fill(0);
    const series = ref([
      {
        name: "Ticketed",
        data: month
      }
    ]);
    const chartOptions = ref({
      chart: {
        type: "line",
        height: 300,
        events: {
          dataPointMouseEnter: (event, chartContext, config) => {
            console.log("Hovered data:", config.w.config.series[config.seriesIndex].data[config.dataPointIndex]);
          }
        }
      },
      dataLabels: {
        enabled: true,
        formatter: (val) => {
          return val;
        }
      },
      stroke: {
        curve: "smooth"
      },
      title: {
        text: "Monthly Data",
        align: "left"
      },
      grid: {
        row: {
          colors: ["#f3f3f3", "transparent"],
          opacity: 0.5
        }
      },
      xaxis: {
        categories: [
          "Jan",
          "Feb",
          "Mar",
          "Apr",
          "May",
          "Jun",
          "Jul",
          "Aug",
          "Sept",
          "Oct",
          "Nov",
          "Dec"
        ]
      },
      tooltip: {
        enabled: true,
        x: {
          format: "dd/MM/yy HH:mm"
        },
        y: {
          formatter: (val) => {
            return `${val}`;
          }
        }
      }
    });
    const series2 = ref([]);
    const labels = ref([]);
    const chartOptions2 = ref({
      chart: {
        type: "bar",
        height: 350
      },
      plotOptions: {
        bar: {
          horizontal: true,
          // Setting the bar chart to be horizontal
          borderRadius: 5
        }
      },
      xaxis: {
        categories: labels.value
        // Initially set categories to labels.value
      },
      fill: {
        opacity: 1
      },
      stroke: {
        width: 1,
        colors: void 0
      },
      dataLabels: {
        enabled: false
      },
      legend: {
        position: "left",
        floating: false,
        itemMargin: {}
      },
      tooltip: {
        y: {
          formatter: function(val) {
            return val === 0 ? "0" : Math.round(val).toString();
          }
        }
      },
      responsive: [{
        breakpoint: 480,
        options: {
          chart: {
            width: 300
          },
          legend: {
            position: "bottom",
            floating: false,
            itemMargin: {}
          }
        }
      }]
    });
    watch(labels, (newLabels) => {
      chartOptions2.value = {
        ...chartOptions2.value,
        xaxis: {
          categories: newLabels
          // Update categories in x-axis with new labels
        }
      };
    });
    const series3 = ref([]);
    const chartOptions3 = ref({});
    const series4 = ref([]);
    const chartOptions4 = ref({});
    const populateViolationData = () => {
      if (props.topViolations && Array.isArray(props.topViolations)) {
        const filteredViolations = props.topViolations.filter((v) => v.count > 0);
        labels.value = filteredViolations.map((v) => v.name);
        const counts = filteredViolations.map((v) => v.count);
        series2.value = [{
          name: "Violations",
          data: counts
        }];
      }
    };
    const populateMonthData = () => {
      if (props.vehicle && Array.isArray(props.vehicle)) {
        props.vehicle.forEach((v) => {
          const monthIndex = new Date(v.created_at).getMonth();
          month[monthIndex]++;
        });
      }
    };
    const populateAgeGroupData = () => {
      if (props.vehicle && Array.isArray(props.vehicle)) {
        const ageGroups = {
          "15-20 years": { count: 0, ages: [] },
          "21-30 years": { count: 0, ages: [] },
          "31-40 years": { count: 0, ages: [] },
          "41-50 years": { count: 0, ages: [] },
          "51+ years": { count: 0, ages: [] }
        };
        props.vehicle.forEach((v) => {
          if (v.age) {
            const vehicleAge = v.age;
            if (vehicleAge >= 15 && vehicleAge <= 20) {
              ageGroups["15-20 years"].count++;
              ageGroups["15-20 years"].ages.push(vehicleAge);
            } else if (vehicleAge >= 21 && vehicleAge <= 30) {
              ageGroups["21-30 years"].count++;
              ageGroups["21-30 years"].ages.push(vehicleAge);
            } else if (vehicleAge >= 31 && vehicleAge <= 40) {
              ageGroups["31-40 years"].count++;
              ageGroups["31-40 years"].ages.push(vehicleAge);
            } else if (vehicleAge >= 41 && vehicleAge <= 50) {
              ageGroups["41-50 years"].count++;
              ageGroups["41-50 years"].ages.push(vehicleAge);
            } else if (vehicleAge >= 51) {
              ageGroups["51+ years"].count++;
              ageGroups["51+ years"].ages.push(vehicleAge);
            }
          }
        });
        series3.value = [{
          name: "Violations",
          data: Object.values(ageGroups).map((group) => group.count)
        }];
        chartOptions3.value = {
          chart: {
            type: "line",
            toolbar: {
              show: false
            }
          },
          xaxis: {
            categories: Object.keys(ageGroups),
            title: {
              text: "Age Group"
            }
          },
          yaxis: {
            title: {
              text: "Number of Violations"
            }
          },
          title: {
            text: "Most Violated Age Groups",
            align: "center"
          },
          tooltip: {
            custom: ({ seriesIndex, dataPointIndex, w }) => {
              const ageGroup = Object.keys(ageGroups)[dataPointIndex];
              const agesInGroup = ageGroups[ageGroup].ages;
              return `
                        <div class="tooltip-custom">
                            <strong>${ageGroup}</strong><br>
                            Violations: ${w.globals.series[seriesIndex][dataPointIndex]}<br>
                            Ages: ${agesInGroup.join(", ")}
                        </div>
                    `;
            }
          }
        };
      }
    };
    const populateGenderData = () => {
      if (props.driver && Array.isArray(props.driver)) {
        const genderCounts = {
          "Male": 0,
          "Female": 0
        };
        props.driver.forEach((d) => {
          if (d.gender) {
            if (d.gender === "1") {
              genderCounts["Male"]++;
            } else if (d.gender === "2") {
              genderCounts["Female"]++;
            }
          }
        });
        series4.value = [genderCounts["Male"], genderCounts["Female"]];
        chartOptions4.value = {
          chart: {
            type: "pie",
            toolbar: {
              show: false
            }
          },
          labels: ["Male", "Female"],
          // Gender categories
          title: {
            text: "Gender Distribution of Drivers",
            align: "center"
          },
          tooltip: {
            y: {
              formatter: (value) => {
                return `${value} drivers`;
              }
            }
          }
        };
      }
    };
    onMounted(() => {
      populateMonthData();
      populateViolationData();
      populateAgeGroupData();
      populateGenderData();
      searchForm.search = props.year;
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_iconify_icon = resolveComponent("iconify-icon");
      const _component_apexchart = resolveComponent("apexchart");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "wrapper" }, _attrs))}>`);
      _push(ssrRenderComponent(_sfc_main$1, { page: "Dashboard" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, null, null, _parent));
      _push(`<div class="page-content"><div class="container-fluid"><div class="row"><div class="col-12"><div class="page-title-box"><h4 class="mb-0"></h4><ol class="breadcrumb mb-0"></ol></div></div></div><div class="row"><div class="col-md-6 col-xl-6">`);
      _push(ssrRenderComponent(unref(Link), {
        href: _ctx.route("admin.ticket-history")
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="card shadow-lg"${_scopeId}><div class="card-body"${_scopeId}><div class="row"${_scopeId}><div class="col-6"${_scopeId}><div class="avatar-md bg-light bg-opacity-50 rounded"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_iconify_icon, {
              icon: "fluent:road-cone-20-filled",
              class: "fs-32 text-warning avatar-title"
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="col-6 text-end"${_scopeId}><p class="text-muted mb-0 text-truncate fw-bold"${_scopeId}>Road/Traffic Violations</p><h3 class="text-dark mt-1 mb-0 fs-2 fw-bold"${_scopeId}>${ssrInterpolate(__props.vehicleCount)}</h3></div></div></div><div class="card-footer py-2 bg-light bg-opacity-50"${_scopeId}><div class="d-flex align-items-center justify-content-between"${_scopeId}><div${_scopeId}><span class="text-muted ms-1 fs-12 me-1"${_scopeId}>Year</span><span class="text-success fw-bold"${_scopeId}>${ssrInterpolate(__props.year)}</span></div><a href="#!" class="text-reset fw-semibold fs-12"${_scopeId}>More Info</a></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "card shadow-lg" }, [
                createVNode("div", { class: "card-body" }, [
                  createVNode("div", { class: "row" }, [
                    createVNode("div", { class: "col-6" }, [
                      createVNode("div", { class: "avatar-md bg-light bg-opacity-50 rounded" }, [
                        createVNode(_component_iconify_icon, {
                          icon: "fluent:road-cone-20-filled",
                          class: "fs-32 text-warning avatar-title"
                        })
                      ])
                    ]),
                    createVNode("div", { class: "col-6 text-end" }, [
                      createVNode("p", { class: "text-muted mb-0 text-truncate fw-bold" }, "Road/Traffic Violations"),
                      createVNode("h3", { class: "text-dark mt-1 mb-0 fs-2 fw-bold" }, toDisplayString(__props.vehicleCount), 1)
                    ])
                  ])
                ]),
                createVNode("div", { class: "card-footer py-2 bg-light bg-opacity-50" }, [
                  createVNode("div", { class: "d-flex align-items-center justify-content-between" }, [
                    createVNode("div", null, [
                      createVNode("span", { class: "text-muted ms-1 fs-12 me-1" }, "Year"),
                      createVNode("span", { class: "text-success fw-bold" }, toDisplayString(__props.year), 1)
                    ]),
                    createVNode("a", {
                      href: "#!",
                      class: "text-reset fw-semibold fs-12"
                    }, "More Info")
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="col-md-6 col-xl-6">`);
      _push(ssrRenderComponent(unref(Link), {
        href: _ctx.route("unpaid")
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="card shadow-lg"${_scopeId}><div class="card-body"${_scopeId}><div class="row"${_scopeId}><div class="col-6"${_scopeId}><div class="avatar-md bg-light bg-opacity-50 rounded"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_iconify_icon, {
              icon: "streamline:ticket-1-solid",
              class: "fs-32 text-danger avatar-title"
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="col-6 text-end"${_scopeId}><p class="text-muted mb-0 text-truncate fw-bold"${_scopeId}>To Pay (Penalty Tickets)</p><h3 class="text-dark mt-1 mb-0 fs-2 fw-bold"${_scopeId}>${ssrInterpolate(__props.unpaid)}</h3></div></div></div><div class="card-footer py-2 bg-light bg-opacity-50"${_scopeId}><div class="d-flex align-items-center justify-content-between"${_scopeId}><div${_scopeId}> --- </div><a href="#!" class="text-reset fw-semibold fs-12"${_scopeId}>More Info</a></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "card shadow-lg" }, [
                createVNode("div", { class: "card-body" }, [
                  createVNode("div", { class: "row" }, [
                    createVNode("div", { class: "col-6" }, [
                      createVNode("div", { class: "avatar-md bg-light bg-opacity-50 rounded" }, [
                        createVNode(_component_iconify_icon, {
                          icon: "streamline:ticket-1-solid",
                          class: "fs-32 text-danger avatar-title"
                        })
                      ])
                    ]),
                    createVNode("div", { class: "col-6 text-end" }, [
                      createVNode("p", { class: "text-muted mb-0 text-truncate fw-bold" }, "To Pay (Penalty Tickets)"),
                      createVNode("h3", { class: "text-dark mt-1 mb-0 fs-2 fw-bold" }, toDisplayString(__props.unpaid), 1)
                    ])
                  ])
                ]),
                createVNode("div", { class: "card-footer py-2 bg-light bg-opacity-50" }, [
                  createVNode("div", { class: "d-flex align-items-center justify-content-between" }, [
                    createVNode("div", null, " --- "),
                    createVNode("a", {
                      href: "#!",
                      class: "text-reset fw-semibold fs-12"
                    }, "More Info")
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><hr class="my-3"><div class="col-md-6 col-xl-6 mt-2"><h5 class="fw-bold fs-5 text-muted mt-2">Data Analytics ${ssrInterpolate(__props.year)}</h5></div><div class="col-md-6 col-xl-6 mt-2"><form action=""><div class="d-flex justify-content-between aligh-items-center mb-4"><select id="year" class="form-select" required><!--[-->`);
      ssrRenderList(unref(years), (year) => {
        _push(`<option${ssrRenderAttr("value", year)}>${ssrInterpolate(year)}</option>`);
      });
      _push(`<!--]--></select><button class="btn btn-success ms-3 d-flex justify-content-center align-items-center shadow-lg">`);
      _push(ssrRenderComponent(_component_iconify_icon, {
        icon: "mingcute:search-fill",
        class: "mb-2 me-2",
        width: "24",
        height: "24"
      }, null, _parent));
      _push(`</button></div></form></div><div class="card"><div class="card-body"><div class="row"><div class="col-md-6">`);
      _push(ssrRenderComponent(_component_apexchart, {
        type: "area",
        options: chartOptions.value,
        series: series.value,
        height: "500"
      }, null, _parent));
      _push(`</div><div class="col-md-6"><div class="fw-bold text-secondary">Top Highest Violations Recorded</div><div class="mt-4">`);
      _push(ssrRenderComponent(_component_apexchart, {
        type: "bar",
        options: chartOptions2.value,
        series: series2.value,
        height: "400"
      }, null, _parent));
      _push(`</div></div><div class="col-md-6"><div class="mt-4">`);
      _push(ssrRenderComponent(_component_apexchart, {
        type: "line",
        options: chartOptions3.value,
        series: series3.value,
        height: "400"
      }, null, _parent));
      _push(`</div></div><div class="col-md-6"><div>`);
      _push(ssrRenderComponent(_component_apexchart, {
        type: "pie",
        options: chartOptions4.value,
        series: series4.value,
        height: "400"
      }, null, _parent));
      _push(`</div></div></div></div></div></div></div>`);
      _push(ssrRenderComponent(Footer, null, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Dashboard.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
