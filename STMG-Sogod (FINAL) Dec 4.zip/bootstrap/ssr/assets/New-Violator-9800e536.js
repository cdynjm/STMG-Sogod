import { ref, onMounted, mergeProps, unref, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual, ssrRenderList } from "vue/server-renderer";
import { useForm } from "@inertiajs/vue3";
import { _ as _sfc_main$1, a as _sfc_main$2 } from "./Sidebar-471d4597.js";
import { F as Footer } from "./Footer-7a30cc67.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
const _sfc_main = {
  __name: "New-Violator",
  __ssrInlineRender: true,
  props: {
    auth: Array,
    violations: Object
  },
  setup(__props) {
    const successToast = ref(null);
    const label = useForm({ response: null, penalty: null });
    onMounted(() => {
      successToast.value = new bootstrap.Toast($("#success-toast"), {
        keyboard: false
      });
      fetchRegions();
    });
    const createForm = useForm({
      firstname: null,
      middlename: null,
      lastname: null,
      suffix: null,
      region: null,
      province: null,
      municipal: null,
      barangay: null,
      birthdate: null,
      age: null,
      address: null,
      gender: null,
      contactNumber: null,
      timesTicketed: null,
      IDtype: null,
      IDnumber: null,
      isDriversLicense: false,
      vehicle: null,
      plateNumber: null,
      violationFee: null,
      location: null,
      violations: [],
      violationAmounts: [],
      // Changed to an object for mapping by violation ID
      error: null,
      status: null,
      vehicleTypes: [
        "Taxi-sedan - taxicabs",
        "PUJ -  transport passengers/cargoes",
        "Taxi-UV - Utility Vehicles",
        "Buses - (TB) BUSES",
        "TC - motorcycles/tricycles (with sidecars) for-hire",
        "Light-PU - passenger cars for-hire",
        "Medium-PU - passenger cars for-hire",
        "SUV - SPORTS UTILITY VEHICLE",
        "TRL - trailers"
      ]
      // Array of vehicle types
    });
    const regions = ref([]);
    const provinces = ref([]);
    const municipals = ref([]);
    const barangays = ref([]);
    const fetchRegions = async () => {
      try {
        const response = await axios.get("/user/regions");
        regions.value = response.data;
      } catch (error) {
        console.error("Error fetching regions:", error);
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "wrapper" }, _attrs))}>`);
      _push(ssrRenderComponent(_sfc_main$1, { page: "New Violator" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, null, null, _parent));
      _push(`<div class="toast-container position-fixed top-0 start-50 translate-middle-x p-4"><div id="success-toast" class="toast" role="alert" aria-live="assertive" aria-atomic="true"><div class="toast-header"><div class="auth-logo me-auto"><span class="fs-4 fw-bold"> Done </span></div><small class="text-success fs-4"><i class="fa-solid fa-circle-check"></i></small><button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button></div><div class="toast-body">${ssrInterpolate(unref(label).response)}</div></div></div><div class="page-content"><div class="container-fluid"><div class="row"><div class="col-md-12"><div class="card"><div class="card-header"><div class="d-flex justify-content-between align-items-center"><h6 class="fw-bold">Create New Violator</h6></div></div><div class="card-body"><form action=""><div class="row"><div class="col-md-6 mb-4"><p class="mb-2">Personal &amp; Vehicle Information</p><div class="row"><div class="col-md-6"><label for="" class="mb-1">First Name</label><input type="text" class="form-control mb-2 text-uppercase"${ssrRenderAttr("value", unref(createForm).firstname)} required></div><div class="col-md-6"><label for="" class="mb-1">Middle Name</label><input type="text" class="form-control mb-2 text-uppercase"${ssrRenderAttr("value", unref(createForm).middlename)}></div></div><div class="row"><div class="col-md-6"><label for="" class="mb-1">Last Name</label><input type="text" class="form-control mb-2 text-uppercase"${ssrRenderAttr("value", unref(createForm).lastname)} required></div><div class="col-md-6"><label for="" class="mb-1">Suffix</label><input type="text" class="form-control mb-2 text-uppercase"${ssrRenderAttr("value", unref(createForm).suffix)}></div></div><label for="" class="my-2">ADDRESS</label><div class="row"><div class="col-md-6"><label for="region" class="mb-1">Region</label><select class="form-select mb-3" required><option value="" disabled${ssrIncludeBooleanAttr(Array.isArray(unref(createForm).region) ? ssrLooseContain(unref(createForm).region, "") : ssrLooseEqual(unref(createForm).region, "")) ? " selected" : ""}>Select a Region</option><!--[-->`);
      ssrRenderList(regions.value, (region) => {
        _push(`<option${ssrRenderAttr("value", region.regCode)}>${ssrInterpolate(region.regDesc)}</option>`);
      });
      _push(`<!--]--></select></div><div class="col-md-6"><label for="province" class="mb-1">Province</label><select class="form-select mb-3" required><option value="" disabled${ssrIncludeBooleanAttr(Array.isArray(unref(createForm).province) ? ssrLooseContain(unref(createForm).province, "") : ssrLooseEqual(unref(createForm).province, "")) ? " selected" : ""}>Select a Province</option><!--[-->`);
      ssrRenderList(provinces.value, (province) => {
        _push(`<option${ssrRenderAttr("value", province.provCode)}>${ssrInterpolate(province.provDesc)}</option>`);
      });
      _push(`<!--]--></select></div></div><div class="row"><div class="col-md-6"><label for="municipal" class="mb-1">Municipal</label><select class="form-select mb-3" required><option value="" disabled${ssrIncludeBooleanAttr(Array.isArray(unref(createForm).municipal) ? ssrLooseContain(unref(createForm).municipal, "") : ssrLooseEqual(unref(createForm).municipal, "")) ? " selected" : ""}>Select a Municipal</option><!--[-->`);
      ssrRenderList(municipals.value, (municipal) => {
        _push(`<option${ssrRenderAttr("value", municipal.citymunCode)}>${ssrInterpolate(municipal.citymunDesc)}</option>`);
      });
      _push(`<!--]--></select></div><div class="col-md-6"><label for="barangay" class="mb-1">Barangay</label><select class="form-select mb-3" required><option value="" disabled${ssrIncludeBooleanAttr(Array.isArray(unref(createForm).barangay) ? ssrLooseContain(unref(createForm).barangay, "") : ssrLooseEqual(unref(createForm).barangay, "")) ? " selected" : ""}>Select a Barangay</option><!--[-->`);
      ssrRenderList(barangays.value, (barangay) => {
        _push(`<option${ssrRenderAttr("value", barangay.brgyCode)}>${ssrInterpolate(barangay.brgyDesc)}</option>`);
      });
      _push(`<!--]--></select></div></div><div class="row mb-2"><div class="col-md-6"><label for="birthdate" class="mb-1">Birth Date</label><input type="date" class="form-control mb-2 text-uppercase"${ssrRenderAttr("value", unref(createForm).birthdate)} required></div><div class="col-md-6"><label for="age" class="mb-1">Age</label><input type="text" class="form-control mb-2"${ssrRenderAttr("value", unref(createForm).age)} readonly></div></div><label for="birthdate" class="mb-1">Gender</label><select name="" id="" class="form-select mb-3"><option value="1"${ssrIncludeBooleanAttr(Array.isArray(unref(createForm).gender) ? ssrLooseContain(unref(createForm).gender, "1") : ssrLooseEqual(unref(createForm).gender, "1")) ? " selected" : ""}>Male</option><option value="2"${ssrIncludeBooleanAttr(Array.isArray(unref(createForm).gender) ? ssrLooseContain(unref(createForm).gender, "2") : ssrLooseEqual(unref(createForm).gender, "2")) ? " selected" : ""}>Female</option></select><div class="row"><div class="col-md-6"><label for="" class="mb-1">Type of Validated Identification Card (ID)</label><div><label><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray(unref(createForm).isDriversLicense) ? ssrLooseContain(unref(createForm).isDriversLicense, null) : unref(createForm).isDriversLicense) ? " checked" : ""} class="form-check-input"> Driver&#39;s License </label></div></div>`);
      if (unref(createForm).isDriversLicense) {
        _push(`<div class="col-md-6"><label for="" class="mb-1">ID Number</label><input type="text" class="form-control mb-2 text-uppercase"${ssrRenderAttr("value", unref(createForm).IDnumber)} required></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div><div class="col-md-6 mb-4"><p class="mb-2">Vehicle Information</p><label for="" class="mb-1">Type of Vehicle</label><select class="form-select mb-2 text-uppercase" required><!--[-->`);
      ssrRenderList(unref(createForm).vehicleTypes, (vehicle) => {
        _push(`<option${ssrRenderAttr("value", vehicle)}>${ssrInterpolate(vehicle)}</option>`);
      });
      _push(`<!--]--></select><label for="" class="mb-1">Plate Number</label><input name="" id="" class="form-control mb-2 text-uppercase"${ssrRenderAttr("value", unref(createForm).plateNumber)} required><label for="" class="mb-1">Location</label><input type="text" class="form-control mb-2 text-uppercase"${ssrRenderAttr("value", unref(createForm).location)} required></div><div class="col-md-12"><p class="fw-bold text-danger mb-2">Driver&#39;s Violation/s</p><div class="table-responsive"><table class="table text-wrap w-100"><thead><tr><th>Violation/s</th></tr></thead><tbody><!--[-->`);
      ssrRenderList(__props.violations, (vl, index) => {
        _push(`<tr><td class="d-flex align-items-center"><input type="checkbox"${ssrRenderAttr("value", vl.id)} class="me-2"${ssrIncludeBooleanAttr(Array.isArray(unref(createForm).violations) ? ssrLooseContain(unref(createForm).violations, vl.id) : unref(createForm).violations) ? " checked" : ""}><span>${ssrInterpolate(vl.violation)}</span></td></tr>`);
      });
      _push(`<!--]--></tbody></table></div></div><div class="col-md-12"><div class="text-center"><button class="btn btn-success shadow-lg mt-2">Submit</button></div></div></div></form></div></div></div></div></div>`);
      _push(ssrRenderComponent(Footer, null, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/User/New-Violator.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
