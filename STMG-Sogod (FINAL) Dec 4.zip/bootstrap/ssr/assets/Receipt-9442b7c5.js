import { resolveComponent, mergeProps, withCtx, createVNode, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderStyle, ssrRenderList, ssrRenderComponent, ssrInterpolate, ssrRenderAttr } from "vue/server-renderer";
import "@inertiajs/vue3";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.js";
const Receipt_vue_vue_type_style_index_0_scoped_2615be5f_lang = "";
function formatDate(dateString) {
  const options = {
    year: "numeric",
    month: "short",
    day: "numeric"
  };
  const date = new Date(dateString);
  return date.toLocaleDateString("en-US", options);
}
function formatNumber(value) {
  return new Intl.NumberFormat("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(value);
}
function numberToWords(number) {
  const units = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"];
  const teens = ["", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"];
  const tens = ["", "Ten", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];
  const thousands = ["", "Thousand", "Million", "Billion"];
  if (number === 0)
    return "Zero PESOS";
  const convertHundreds = (num) => {
    let str = "";
    if (num > 99) {
      str += units[Math.floor(num / 100)] + " Hundred ";
      num %= 100;
    }
    if (num > 10 && num < 20) {
      str += teens[num - 10] + " ";
    } else {
      str += tens[Math.floor(num / 10)] + " ";
      str += units[num % 10] + " ";
    }
    return str.trim();
  };
  const convertToWords = (num) => {
    let wordString = "";
    let i = 0;
    while (num > 0) {
      const chunk = num % 1e3;
      if (chunk) {
        wordString = convertHundreds(chunk) + " " + thousands[i] + " " + wordString;
      }
      num = Math.floor(num / 1e3);
      i++;
    }
    return wordString.trim();
  };
  const pesos = Math.floor(number);
  const centavos = Math.round((number - pesos) * 100);
  let result = convertToWords(pesos) + " PESOS";
  if (centavos > 0) {
    result += " AND " + convertToWords(centavos) + " CENTAVOS";
  }
  return result.trim();
}
const _sfc_main = {
  __name: "Receipt",
  __ssrInlineRender: true,
  props: {
    receipt: Object
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_center = resolveComponent("center");
      _push(`<html${ssrRenderAttrs(mergeProps({ lang: "en" }, _attrs))} data-v-2615be5f><head data-v-2615be5f><meta charset="UTF-8" data-v-2615be5f><meta name="viewport" content="width=device-width, initial-scale=1.0" data-v-2615be5f><title data-v-2615be5f>Invoice Receipt</title></head><body data-v-2615be5f><div class="buttons" data-v-2615be5f><div style="${ssrRenderStyle({ "display": "flex", "align-items": "center" })}" data-v-2615be5f><a href="/" data-v-2615be5f>Back</a><button data-v-2615be5f>Print Receipt</button></div></div><!--[-->`);
      ssrRenderList(2, (copy, index) => {
        _push(`<div data-v-2615be5f><div class="receipt" data-v-2615be5f><table style="${ssrRenderStyle({ "width": "100%", "margin-bottom": "7px" })}" data-v-2615be5f><tr data-v-2615be5f><td style="${ssrRenderStyle({ "border-bottom": "2px solid black" })}" data-v-2615be5f>`);
        _push(ssrRenderComponent(_component_center, null, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<img src="/logo/ph-logo.png" width="60" alt="" data-v-2615be5f${_scopeId}>`);
            } else {
              return [
                createVNode("img", {
                  src: "/logo/ph-logo.png",
                  width: "60",
                  alt: ""
                })
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</td><td style="${ssrRenderStyle({ "border": "2px solid black", "border-top": "0px" })}" data-v-2615be5f>`);
        _push(ssrRenderComponent(_component_center, null, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<p data-v-2615be5f${_scopeId}>Repubic of the Philippines</p><p data-v-2615be5f${_scopeId}>OFFICE OF THE PROVINCIAL TREASURER</p><p data-v-2615be5f${_scopeId}>Province of Southern Leyte</p><input type="text" value="SOGOD" readonly style="${ssrRenderStyle({ "text-align": "center", "margin-bottom": "0", "border-bottom": "1px solid black", "font-weight": "bold" })}" data-v-2615be5f${_scopeId}><p data-v-2615be5f${_scopeId}>Municipality</p>`);
            } else {
              return [
                createVNode("p", null, "Repubic of the Philippines"),
                createVNode("p", null, "OFFICE OF THE PROVINCIAL TREASURER"),
                createVNode("p", null, "Province of Southern Leyte"),
                createVNode("input", {
                  type: "text",
                  value: "SOGOD",
                  readonly: "",
                  style: { "text-align": "center", "margin-bottom": "0", "border-bottom": "1px solid black", "font-weight": "bold" }
                }),
                createVNode("p", null, "Municipality")
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</td><td style="${ssrRenderStyle({ "border": "2px solid black", "border-top": "0px" })}" data-v-2615be5f>`);
        _push(ssrRenderComponent(_component_center, null, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<img src="/logo/province-logo.png" width="60" alt="" data-v-2615be5f${_scopeId}>`);
            } else {
              return [
                createVNode("img", {
                  src: "/logo/province-logo.png",
                  width: "60",
                  alt: ""
                })
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</td><td style="${ssrRenderStyle({ "border-top": "none", "border-right": "1px solid black" })}" data-v-2615be5f></td><td style="${ssrRenderStyle({ "border": "2px solid black", "border-bottom": "2px solid black", "padding": "0", "border-top": "0px", "border-right": "0px" })}" data-v-2615be5f><table style="${ssrRenderStyle({ "border-collapse": "collapse", "width": "100%" })}" data-v-2615be5f><tr data-v-2615be5f><td style="${ssrRenderStyle({ "background-color": "black", "color": "white", "padding": "10px", "border-bottom": "1px solid black", "text-align": "center", "width": "50%" })}" data-v-2615be5f><small data-v-2615be5f>OFFICIAL RECEIPT</small></td><td style="${ssrRenderStyle({ "border-bottom": "1px solid black", "padding": "10px", "text-align": "left" })}" data-v-2615be5f><small data-v-2615be5f>No. SL</small> <span style="${ssrRenderStyle({ "font-weight": "bold", "font-size": "1.2em", "padding-left": "5px" })}" data-v-2615be5f>${ssrInterpolate(__props.receipt.ORnumber)}</span></td></tr><tr data-v-2615be5f><td colspan="4" style="${ssrRenderStyle({ "display": "flex", "align-items": "center", "padding": "10px 0px 10px" })}" data-v-2615be5f><span style="${ssrRenderStyle({ "display": "inline-block", "width": "0", "height": "0", "border-top": "15px solid transparent", "border-bottom": "15px solid transparent", "border-left": "25px solid black" })}" data-v-2615be5f></span><small style="${ssrRenderStyle({ "margin-left": "5px" })}" data-v-2615be5f>VALIDATION DATE</small></td></tr></table></td></tr></table><table style="${ssrRenderStyle({ "width": "100%", "margin-bottom": "7px" })}" data-v-2615be5f><tr data-v-2615be5f><td style="${ssrRenderStyle({ "border": "1px solid black", "border-left": "0px" })}" colspan="2" data-v-2615be5f><small style="${ssrRenderStyle({ "margin-left": "10px" })}" data-v-2615be5f>PAYOR</small><div style="${ssrRenderStyle({ "margin-left": "10px" })}" data-v-2615be5f>${ssrInterpolate(__props.receipt.driverinfo.name)}</div></td><td style="${ssrRenderStyle({ "border": "1px solid black", "padding-bottom": "15px" })}" data-v-2615be5f><small style="${ssrRenderStyle({ "margin-left": "10px" })}" data-v-2615be5f>FUND</small></td><td style="${ssrRenderStyle({ "border": "1px solid black", "border-right": "0px" })}" data-v-2615be5f><small style="${ssrRenderStyle({ "margin-left": "10px" })}" data-v-2615be5f>DATE</small><div style="${ssrRenderStyle({ "margin-left": "10px" })}" data-v-2615be5f>${ssrInterpolate(formatDate(__props.receipt.datePaid))}</div></td></tr></table><table style="${ssrRenderStyle({ "width": "100%", "margin-bottom": "7px" })}" data-v-2615be5f><tr data-v-2615be5f><th style="${ssrRenderStyle({ "border": "1px solid black", "border-left": "0px", "text-align": "center" })}" colspan="2" data-v-2615be5f><small data-v-2615be5f><b data-v-2615be5f>NATURE OF COLLECTION</b></small></th><th style="${ssrRenderStyle({ "border": "1px solid black", "text-align": "center" })}" data-v-2615be5f><small data-v-2615be5f><b data-v-2615be5f>ACCOUNT CODE</b></small></th><th style="${ssrRenderStyle({ "border": "1px solid black", "border-right": "0px", "text-align": "center" })}" data-v-2615be5f><small data-v-2615be5f><b data-v-2615be5f>AMOUNT</b></small></th></tr><tr data-v-2615be5f><td style="${ssrRenderStyle({ "border": "1px solid black", "border-left": "0px", "text-align": "center" })}" colspan="2" data-v-2615be5f>Penalty Collection for Violation of Traffic Rules and Regulations</td><td style="${ssrRenderStyle({ "border": "1px solid black", "padding": "10px" })}" data-v-2615be5f></td><td style="${ssrRenderStyle({ "border": "1px solid black", "border-right": "0px" })}" data-v-2615be5f>₱ ${ssrInterpolate(formatNumber(__props.receipt.violationFee))}</td></tr><!--[-->`);
        ssrRenderList(3, (i) => {
          _push(`<tr data-v-2615be5f><td style="${ssrRenderStyle({ "border": "1px solid black", "padding": "10px", "border-left": "0px" })}" colspan="2" data-v-2615be5f></td><td style="${ssrRenderStyle({ "border": "1px solid black", "padding": "10px" })}" data-v-2615be5f></td><td style="${ssrRenderStyle({ "border": "1px solid black", "padding": "10px", "border-right": "0px" })}" data-v-2615be5f></td></tr>`);
        });
        _push(`<!--]--><tr data-v-2615be5f><td style="${ssrRenderStyle({ "border": "1px solid black", "padding": "0px", "border-left": "0px" })}" colspan="2" data-v-2615be5f><small data-v-2615be5f><strong style="${ssrRenderStyle({ "margin-left": "10px" })}" data-v-2615be5f>TOTAL</strong></small></td><td style="${ssrRenderStyle({ "border": "1px solid black", "padding": "10px" })}" data-v-2615be5f></td><td style="${ssrRenderStyle({ "border": "1px solid black", "border-right": "0px" })}" data-v-2615be5f><b data-v-2615be5f>₱ ${ssrInterpolate(formatNumber(__props.receipt.violationFee))}</b></td></tr><tr data-v-2615be5f><td style="${ssrRenderStyle({ "border": "1px solid black", "padding": "0px", "border-left": "0px" })}" colspan="3" data-v-2615be5f><small style="${ssrRenderStyle({ "margin-left": "10px" })}" data-v-2615be5f>AMOUNT IN WORDS</small><span style="${ssrRenderStyle({ "text-transform": "uppercase", "margin-left": "10px" })}" data-v-2615be5f>${ssrInterpolate(numberToWords(__props.receipt.violationFee))}</span></td><td style="${ssrRenderStyle({ "border": "1px solid black", "padding": "10px", "border-right": "0px" })}" data-v-2615be5f></td></tr></table><table style="${ssrRenderStyle({ "width": "100%" })}" data-v-2615be5f><tr data-v-2615be5f><td style="${ssrRenderStyle({ "border": "1px solid black", "border-bottom": "0px", "padding": "10px", "border-left": "0px" })}" colspan="1" data-v-2615be5f><div data-v-2615be5f><input type="checkbox" checked disabled data-v-2615be5f><label for="" style="${ssrRenderStyle({ "margin-left": "5px" })}" data-v-2615be5f>Cash</label></div><div data-v-2615be5f><input type="checkbox" data-v-2615be5f><label for="" style="${ssrRenderStyle({ "margin-left": "5px" })}" data-v-2615be5f>Check</label></div><div data-v-2615be5f><input type="checkbox" data-v-2615be5f><label for="" style="${ssrRenderStyle({ "margin-left": "5px" })}" data-v-2615be5f>Money Order</label></div></td><td style="${ssrRenderStyle({ "border": "1px solid black", "padding": "0px", "border-bottom": "0px" })}" data-v-2615be5f><table style="${ssrRenderStyle({ "width": "100%" })}" data-v-2615be5f><tr data-v-2615be5f><th style="${ssrRenderStyle({ "border": "1px solid black", "border-top": "0px", "border-left": "0px", "text-align": "center" })}" data-v-2615be5f><small data-v-2615be5f><b data-v-2615be5f>DRAWEE BANK</b></small></th><th style="${ssrRenderStyle({ "border": "1px solid black", "border-top": "0px", "text-align": "center" })}" data-v-2615be5f><small data-v-2615be5f><b data-v-2615be5f>NUMBER</b></small></th><th style="${ssrRenderStyle({ "border": "1px solid black", "border-top": "0px", "border-right": "0px", "text-align": "center" })}" data-v-2615be5f><small data-v-2615be5f><b data-v-2615be5f>DATE</b></small></th></tr><tr data-v-2615be5f><td style="${ssrRenderStyle({ "border": "1px solid black", "padding-bottom": "80px", "border-bottom": "0px", "border-left": "0px" })}" data-v-2615be5f></td><td style="${ssrRenderStyle({ "border": "1px solid black", "padding-bottom": "80px", "border-bottom": "0px" })}" data-v-2615be5f></td><td style="${ssrRenderStyle({ "border": "1px solid black", "padding-bottom": "80px", "border-bottom": "0px", "border-right": "0px" })}" data-v-2615be5f></td></tr></table></td><td style="${ssrRenderStyle({ "border": "1px solid black", "padding": "10px", "border-bottom": "0px", "border-right": "0px" })}" data-v-2615be5f><p data-v-2615be5f>Received the Amount</p><p data-v-2615be5f>stated above</p></td><td style="${ssrRenderStyle({ "border": "0px", "border-top": "1px solid black", "padding": "0px" })}" data-v-2615be5f>`);
        _push(ssrRenderComponent(_component_center, null, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<input type="text" style="${ssrRenderStyle({ "width": "95%", "border-bottom": "1px solid black", "text-align": "center", "font-size": "12px" })}"${ssrRenderAttr("value", __props.receipt.treasurer)} readonly data-v-2615be5f${_scopeId}><br data-v-2615be5f${_scopeId}><small data-v-2615be5f${_scopeId}>PROVINCIAL/MUNICIPAL TREASURER</small><br data-v-2615be5f${_scopeId}><input type="text" style="${ssrRenderStyle({ "width": "95%", "border-bottom": "1px solid black", "text-align": "center", "font-size": "12px" })}"${ssrRenderAttr("value", __props.receipt.collector)} readonly data-v-2615be5f${_scopeId}><br data-v-2615be5f${_scopeId}><small data-v-2615be5f${_scopeId}>DEPUTY COLLECTOR</small>`);
            } else {
              return [
                createVNode("input", {
                  type: "text",
                  style: { "width": "95%", "border-bottom": "1px solid black", "text-align": "center", "font-size": "12px" },
                  value: __props.receipt.treasurer,
                  readonly: ""
                }, null, 8, ["value"]),
                createVNode("br"),
                createVNode("small", null, "PROVINCIAL/MUNICIPAL TREASURER"),
                createVNode("br"),
                createVNode("input", {
                  type: "text",
                  style: { "width": "95%", "border-bottom": "1px solid black", "text-align": "center", "font-size": "12px" },
                  value: __props.receipt.collector,
                  readonly: ""
                }, null, 8, ["value"]),
                createVNode("br"),
                createVNode("small", null, "DEPUTY COLLECTOR")
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</td></tr></table></div><div style="${ssrRenderStyle({ "display": "flex", "justify-content": "space-between", "margin": "5px 10px 20px" })}" data-v-2615be5f><p data-v-2615be5f>NOTE: Write the number and date of this receipt on the back of check or money order received.</p><p data-v-2615be5f><strong data-v-2615be5f>${ssrInterpolate(index === 0 ? "ORIGINAL" : "DUPLICATE")}</strong></p></div></div>`);
      });
      _push(`<!--]--></body></html>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Receipt.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Receipt = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-2615be5f"]]);
export {
  Receipt as default
};
