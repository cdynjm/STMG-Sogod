import { mergeProps, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderStyle } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.js";
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "row" }, _attrs))}><div class="col-lg-12"><div class="text-center p-4"><div class="col-12 d-flex align-items-center justify-content-center"><div class="me-1"><a href="https://www.sogodlgu.gov.ph/" target="_blank"><img src="/logo/logo-sogod.gif" class="rounded-circle" style="${ssrRenderStyle({ "width": "50px" })}" alt="Sogod Logo"></a></div><div><p class="text-sm text-secondary mb-0">STMG - Road Traffic Offense IMS</p><p class="fw-bolder text-sm mb-0">Sogod Southern Leyte</p><small>Developed By: Capstone Project Group</small></div><div class="ms-1"><a href="https://www.sogodlgu.gov.ph/" target="_blank"><img src="/logo/stmg-logo.jpg" class="rounded-circle" style="${ssrRenderStyle({ "width": "50px" })}" alt="Sogod Logo"></a></div></div><hr class="mt-2 mx-5"></div></div></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Layouts/Footer.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Footer = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Footer as F
};
