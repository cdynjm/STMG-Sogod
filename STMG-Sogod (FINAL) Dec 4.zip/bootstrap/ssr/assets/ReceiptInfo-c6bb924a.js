import { ref, onMounted, mergeProps, unref, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderAttr } from "vue/server-renderer";
import { useForm } from "@inertiajs/vue3";
import { _ as _sfc_main$1, a as _sfc_main$2 } from "./Sidebar-471d4597.js";
import { F as Footer } from "./Footer-7a30cc67.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
Swal.mixin({
  customClass: {
    confirmButton: "btn btn-danger",
    cancelButton: "btn btn-secondary"
  },
  buttonsStyling: false
});
const _sfc_main = {
  __name: "ReceiptInfo",
  __ssrInlineRender: true,
  props: {
    auth: Array,
    receipt: Object
  },
  setup(__props) {
    const props = __props;
    const successToast = ref(null);
    const label = useForm({ response: null });
    const receiptForm = useForm({
      treasurer: null,
      collector: null,
      error: null,
      status: null
    });
    onMounted(() => {
      successToast.value = new bootstrap.Toast($("#success-toast"), {
        keyboard: false
      });
      receiptForm.treasurer = props.receipt.treasurer;
      receiptForm.collector = props.receipt.collector;
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "wrapper" }, _attrs))}>`);
      _push(ssrRenderComponent(_sfc_main$1, { page: "Staff & Personnel" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, null, null, _parent));
      _push(`<div class="toast-container position-fixed top-0 start-50 translate-middle-x p-4"><div id="success-toast" class="toast" role="alert" aria-live="assertive" aria-atomic="true"><div class="toast-header"><div class="auth-logo me-auto"><span class="fs-4 fw-bold"> Done </span></div><small class="text-success fs-4"><i class="fa-solid fa-circle-check"></i></small><button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button></div><div class="toast-body">${ssrInterpolate(unref(label).response)}</div></div></div><div class="page-content"><div class="container-fluid"><div class="row"><div class="col-md-3"></div><div class="col-md-6"><div class="card"><div class="card-header"><h6>Receipt Info</h6></div><div class="card-body"><form><label for="">Provincial/Municipal Treasurer</label><input type="text" class="form-control mb-2"${ssrRenderAttr("value", unref(receiptForm).treasurer)} required><label for="">Deputy Collector</label><input type="text" class="form-control mb-3"${ssrRenderAttr("value", unref(receiptForm).collector)} required><button class="btn btn-sm btn-success shadow-lg">Update</button></form></div></div></div><div class="col-md-3"></div></div></div>`);
      _push(ssrRenderComponent(Footer, null, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/ReceiptInfo.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
