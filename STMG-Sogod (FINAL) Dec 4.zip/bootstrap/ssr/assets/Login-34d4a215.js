import { ref, resolveComponent, mergeProps, withCtx, createVNode, unref, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderStyle, ssrInterpolate, ssrRenderAttr, ssrRenderDynamicModel, ssrIncludeBooleanAttr, ssrLooseContain } from "vue/server-renderer";
import { useForm, Link } from "@inertiajs/vue3";
import { F as Footer } from "./Footer-7a30cc67.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
const _sfc_main = {
  __name: "Login",
  __ssrInlineRender: true,
  props: {
    canResetPassword: {
      type: Boolean
    },
    status: {
      type: String
    }
  },
  setup(__props) {
    const form = useForm({
      email: null,
      password: null,
      remember: false,
      error: null
    });
    const showPassword = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_center = resolveComponent("center");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "account-pages pt-2 pt-sm-5 pb-4 pb-sm-5" }, _attrs))}><div class="container"><div class="row justify-content-center"><div class="col-xl-5"><div class="card auth-card shadow-lg"><div class="card-body px-3 py-5"><div class="mb-4 text-center auth-logo"><a href="#" class="logo-dark">`);
      _push(ssrRenderComponent(_component_center, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img src="/logo/stmg-2.png" class="me-2" style="${ssrRenderStyle({ "width": "160px" })}" alt="logo dark"${_scopeId}><div class="fw-bold mt-2"${_scopeId}>STMG-Road Traffic Offense IMS</div>`);
          } else {
            return [
              createVNode("img", {
                src: "/logo/stmg-2.png",
                class: "me-2",
                style: { "width": "160px" },
                alt: "logo dark"
              }),
              createVNode("div", { class: "fw-bold mt-2" }, "STMG-Road Traffic Offense IMS")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</a></div><h2 class="fw-bold text-uppercase text-center fs-18">Sign In</h2><p class="text-muted text-center mt-1 mb-4">Enter your account credentials to proceed</p><div class="px-4">`);
      if (unref(form).error) {
        _push(`<div class="alert alert-danger">${ssrInterpolate(unref(form).error)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<form class="authentication-form"><div class="mb-3"><label class="form-label" for="example-email">Email</label><input${ssrRenderAttr("value", unref(form).email)} type="email" id="example-email" name="email" class="form-control bg-light bg-opacity-50 border-light py-2" placeholder="Enter your email" required></div><div class="mb-3"><label class="form-label" for="example-password">Password</label><input${ssrRenderDynamicModel(showPassword.value ? "text" : "password", unref(form).password, null)}${ssrRenderAttr("type", showPassword.value ? "text" : "password")} id="example-password" name="password" class="form-control bg-light bg-opacity-50 border-light py-2" placeholder="Enter your password" required></div><div class="mb-3 d-flex justify-content-between align-items-center"><div class="form-check"><input${ssrIncludeBooleanAttr(Array.isArray(showPassword.value) ? ssrLooseContain(showPassword.value, null) : showPassword.value) ? " checked" : ""} type="checkbox" class="form-check-input" id="checkbox-signin"><small class="form-check-label" for="checkbox-signin">Show Password</small></div>`);
      _push(ssrRenderComponent(unref(Link), {
        href: _ctx.route("password.request"),
        class: "text-muted"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<small${_scopeId}>Forgot password?</small>`);
          } else {
            return [
              createVNode("small", null, "Forgot password?")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="mb-1 text-center d-grid"><button class="btn btn-danger py-2 fw-medium" type="submit">Sign In</button></div><p class="mt-3 fw-semibold no-span"></p><div class="text-center">`);
      _push(ssrRenderComponent(Footer, null, null, _parent));
      _push(`</div></form></div></div></div></div></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Auth/Login.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
