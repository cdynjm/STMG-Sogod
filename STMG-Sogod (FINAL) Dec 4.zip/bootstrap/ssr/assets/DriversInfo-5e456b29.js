import { ref, onMounted, resolveComponent, mergeProps, unref, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderList } from "vue/server-renderer";
import { useForm } from "@inertiajs/vue3";
import { _ as _sfc_main$1, a as _sfc_main$2 } from "./Sidebar-471d4597.js";
import { F as Footer } from "./Footer-7a30cc67.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
Swal.mixin({
  customClass: {
    confirmButton: "btn btn-primary",
    cancelButton: "btn btn-secondary"
  },
  buttonsStyling: false
});
function formatDate(dateString) {
  const options = {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "numeric",
    hour12: true
  };
  const date = new Date(dateString);
  return date.toLocaleDateString("en-US", options);
}
function formatShortDate(dateString) {
  const options = { year: "numeric", month: "short", day: "numeric" };
  const date = new Date(dateString);
  return date.toLocaleDateString("en-US", options);
}
const _sfc_main = {
  __name: "DriversInfo",
  __ssrInlineRender: true,
  props: {
    driverInfo: Object,
    driverVehicle: Object,
    driverViolation: Object,
    auth: Array
  },
  setup(__props) {
    const successToast = ref(null);
    const label = useForm({ response: null });
    onMounted(() => {
      successToast.value = new bootstrap.Toast($("#success-toast"), {
        keyboard: false
      });
    });
    function capitalizeWords(text) {
      if (!text)
        return "";
      return text.toLowerCase().replace(/\b\w/g, (char) => char.toUpperCase());
    }
    function formatOffense(count) {
      const suffixes = ["th", "st", "nd", "rd"];
      const mod = count % 100;
      return count + (suffixes[(mod - 20) % 10] || suffixes[mod] || suffixes[0]) + " Offense";
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_iconify_icon = resolveComponent("iconify-icon");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "wrapper" }, _attrs))}>`);
      _push(ssrRenderComponent(_sfc_main$1, { page: "Driver Information" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, null, null, _parent));
      _push(`<div class="toast-container position-fixed top-0 start-50 translate-middle-x p-4"><div id="success-toast" class="toast" role="alert" aria-live="assertive" aria-atomic="true"><div class="toast-header"><div class="auth-logo me-auto"><span class="fs-4 fw-bold"> Done </span></div><small class="text-success fs-4"><i class="fa-solid fa-circle-check"></i></small><button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button></div><div class="toast-body">${ssrInterpolate(unref(label).response)}</div></div></div><div class="page-content"><div class="container-fluid"><div class="row"><div class="col-md-12"><div class="card"><div class="card-header"><div class="d-flex justify-content-between align-items-center"><h6 class="fw-bold fs-3"><span class="me-2">`);
      _push(ssrRenderComponent(_component_iconify_icon, {
        icon: "pepicons-print:person-circle",
        width: "30",
        height: "30"
      }, null, _parent));
      _push(`</span> ${ssrInterpolate(__props.driverInfo.firstname)} ${ssrInterpolate(__props.driverInfo.middlename)} ${ssrInterpolate(__props.driverInfo.lastname)} ${ssrInterpolate(__props.driverInfo.suffix)}</h6></div></div><div class="card-body"><div class="table-responsive"><p>Address: Brgy. ${ssrInterpolate(__props.driverInfo.barangay != null ? __props.driverInfo.barangay.brgyDesc : "")} ${ssrInterpolate(__props.driverInfo.municipal != null ? capitalizeWords(__props.driverInfo.municipal.citymunDesc) : "")} ${ssrInterpolate(__props.driverInfo.province != null ? capitalizeWords(__props.driverInfo.province.provDesc) : "")}</p><p>Birth Date: ${ssrInterpolate(formatShortDate(__props.driverInfo.birthdate))}</p><p class="fw-bold mt-2">`);
      _push(ssrRenderComponent(_component_iconify_icon, {
        icon: "streamline:ticket-1-solid",
        class: "me-2",
        width: "18",
        height: "18"
      }, null, _parent));
      _push(` Penalty Records History: </p></div></div></div></div></div><div class="row"><!--[-->`);
      ssrRenderList(__props.driverVehicle, (dv, index) => {
        _push(`<div class="col-12"><div class="card"><div class="card-body"><div class="clearfix"><div class="float-sm-end"><address class="mt-3">${ssrInterpolate(dv.location)}<br><small>STATUS: </small>`);
        if (dv.status === 0) {
          _push(`<span class="text-success fw-bold">PAID <div><small class="text-secondary fw-normal">${ssrInterpolate(formatDate(dv.datePaid))}</small><div class="text-secondary"> OR: ${ssrInterpolate(dv.ORnumber)}</div></div></span>`);
        } else {
          _push(`<!---->`);
        }
        if (dv.status === 1) {
          _push(`<span class="text-danger fw-bold">UNPAID</span>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</address></div><div class="float-sm-start"><h5 class="card-title mb-2">Penalty/Violation Ticket</h5><p class="text-info">${ssrInterpolate(formatDate(dv.created_at))}</p></div></div><div class="row mt-3"><div class="col-md-6"><p class="mt-2">Type of Vehicle: <span class="fw-bold">${ssrInterpolate(dv.vehicle)}</span></p><p class="">Plate Number: <span class="fw-bold">${ssrInterpolate(dv.plateNumber)}</span></p><p>ID Information: <span class="fw-bold">Driver&#39;s License - ${ssrInterpolate(dv.IDnumber != null ? dv.IDnumber : "None")}</span></p></div></div><div class="row"><div class="col-12"><div class="table-responsive table-borderless text-nowrap mt-3 table-centered"><table class="table mb-0"><thead class="bg-light bg-opacity-50"><tr><th class="border-0 py-2">Violations</th><th class="border-0 py-2">Offense</th></tr></thead><tbody><!--[-->`);
        ssrRenderList(__props.driverViolation, (dvl, index2) => {
          _push(`<tr>`);
          if (dvl.vehicleID === dv.id) {
            _push(`<td>${ssrInterpolate(dvl.violations.violation)}</td>`);
          } else {
            _push(`<!---->`);
          }
          if (dvl.vehicleID === dv.id) {
            _push(`<td>${ssrInterpolate(formatOffense(dvl.offense))}</td>`);
          } else {
            _push(`<!---->`);
          }
          _push(`</tr>`);
        });
        _push(`<!--]--></tbody></table></div></div></div><div class="row mt-3"><div class="col-sm-7"><div class="clearfix pt-xl-3 pt-0"><h6 class="fw-normal text-muted">Issued/Ticketed By: </h6><h6 class="fs-16 fw-bold my-1">${ssrInterpolate(dv.ticketedBy)}</h6></div></div><div class="col-sm-5"><div class="float-end"></div><div class="clearfix"></div></div></div></div></div></div>`);
      });
      _push(`<!--]--></div></div>`);
      _push(ssrRenderComponent(Footer, null, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/DriversInfo.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
