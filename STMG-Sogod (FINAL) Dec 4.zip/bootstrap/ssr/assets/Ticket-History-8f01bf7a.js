import { ref, onMounted, resolveComponent, mergeProps, unref, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual, ssrRenderList, ssrRenderAttr } from "vue/server-renderer";
import { useForm } from "@inertiajs/vue3";
import { _ as _sfc_main$1, a as _sfc_main$2 } from "./Sidebar-471d4597.js";
import { F as Footer } from "./Footer-7a30cc67.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
Swal.mixin({
  customClass: {
    confirmButton: "btn btn-primary",
    cancelButton: "btn btn-secondary"
  },
  buttonsStyling: false
});
function formatDate(dateString) {
  const options = {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "numeric",
    hour12: true
  };
  const date = new Date(dateString);
  return date.toLocaleDateString("en-US", options);
}
const _sfc_main = {
  __name: "Ticket-History",
  __ssrInlineRender: true,
  props: {
    ticket: Object,
    auth: Array,
    violation: Object,
    year: String
  },
  setup(__props) {
    const props = __props;
    const successToast = ref(null);
    const label = useForm({ response: null });
    onMounted(() => {
      successToast.value = new bootstrap.Toast($("#success-toast"), {
        keyboard: false
      }), $("#ticket-table").DataTable();
    });
    const searchForm = useForm({
      search: null,
      result: 0
    });
    const currentYear = (/* @__PURE__ */ new Date()).getFullYear();
    const startYear = 2020;
    const years = Array.from({ length: currentYear - startYear + 1 }, (_, i) => startYear + i);
    onMounted(() => {
      searchForm.search = props.year;
    });
    function capitalizeWords(text) {
      if (!text)
        return "";
      return text.toLowerCase().replace(/\b\w/g, (char) => char.toUpperCase());
    }
    function formatOffense(count) {
      const suffixes = ["th", "st", "nd", "rd"];
      const mod = count % 100;
      return count + (suffixes[(mod - 20) % 10] || suffixes[mod] || suffixes[0]) + " Offense";
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_iconify_icon = resolveComponent("iconify-icon");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "wrapper" }, _attrs))}>`);
      _push(ssrRenderComponent(_sfc_main$1, { page: "Ticket History" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, null, null, _parent));
      _push(`<div class="toast-container position-fixed top-0 start-50 translate-middle-x p-4"><div id="success-toast" class="toast" role="alert" aria-live="assertive" aria-atomic="true"><div class="toast-header"><div class="auth-logo me-auto"><span class="fs-4 fw-bold"> Done </span></div><small class="text-success fs-4"><i class="fa-solid fa-circle-check"></i></small><button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button></div><div class="toast-body">${ssrInterpolate(unref(label).response)}</div></div></div><div class="page-content"><div class="container-fluid"><div class="row"><div class="col-md-6"><form action=""><label for="" class="mb-2">Select Year</label><div class="d-flex justify-content-between aligh-items-center mb-4"><select id="year" class="form-select" required><option value=""${ssrIncludeBooleanAttr(Array.isArray(unref(searchForm).search) ? ssrLooseContain(unref(searchForm).search, "") : ssrLooseEqual(unref(searchForm).search, "")) ? " selected" : ""}>Select ...</option><!--[-->`);
      ssrRenderList(unref(years), (year) => {
        _push(`<option${ssrRenderAttr("value", year)}>${ssrInterpolate(year)}</option>`);
      });
      _push(`<!--]--></select><button class="btn btn-success ms-3 d-flex justify-content-center align-items-center shadow-lg">`);
      _push(ssrRenderComponent(_component_iconify_icon, {
        icon: "mingcute:search-fill",
        class: "mb-2 me-2",
        width: "24",
        height: "24"
      }, null, _parent));
      _push(`</button></div></form></div><div class="col-md-12"><div class="card"><div class="card-header"><div class="d-flex justify-content-between align-items-center"><h6 class="fw-bold">Penalty Tickets ${ssrInterpolate(__props.year)}</h6></div></div><div class="card-body"><div class="table-responsive"><table id="ticket-table" class="table text-nowrap"><thead><tr class="fs-6"><th>No.</th><th>Name</th><th>Address</th><th>Violation</th><th>Vehicle &amp; Plate No.</th><th>Driver&#39;s License</th></tr></thead><tbody><!--[-->`);
      ssrRenderList(__props.ticket, (tc, index) => {
        _push(`<tr><td>${ssrInterpolate(index + 1)}</td><td><div class="d-flex"><div class="me-4">`);
        _push(ssrRenderComponent(_component_iconify_icon, {
          icon: "pepicons-print:person-circle",
          width: "30",
          height: "30"
        }, null, _parent));
        _push(`</div><div class="mt-1 fw-bold">${ssrInterpolate(tc.driverinfo.firstname)} ${ssrInterpolate(tc.driverinfo.middlename)} ${ssrInterpolate(tc.driverinfo.lastname)} ${ssrInterpolate(tc.driverinfo.suffix)} <hr class="my-1">`);
        if (tc.status === 1) {
          _push(`<div class="fw-normal text-danger"><span>`);
          _push(ssrRenderComponent(_component_iconify_icon, {
            icon: "zondicons:minus-solid",
            width: "17",
            class: "me-1"
          }, null, _parent));
          _push(` TO PAY</span></div>`);
        } else {
          _push(`<!---->`);
        }
        if (tc.status === 0) {
          _push(`<div class="fw-normal text-success"><div>`);
          _push(ssrRenderComponent(_component_iconify_icon, {
            icon: "mingcute:check-2-fill",
            width: "17",
            class: "me-1"
          }, null, _parent));
          _push(` PAID </div><small class="text-secondary fw-bold">${ssrInterpolate(formatDate(tc.datePaid))}</small><div class="text-secondary"> OR: ${ssrInterpolate(tc.ORnumber)}</div></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div></div></td><td class="text-wrap"> Brgy. ${ssrInterpolate(tc.driverinfo.barangay != null ? tc.driverinfo.barangay.brgyDesc : "")} ${ssrInterpolate(tc.driverinfo.municipal != null ? capitalizeWords(tc.driverinfo.municipal.citymunDesc) : "")} ${ssrInterpolate(tc.driverinfo.province != null ? capitalizeWords(tc.driverinfo.province.provDesc) : "")}</td><td><table class="table table-bordered mb-1"><thead><tr><th class="p-1"><small>Violation</small></th><th class="p-1"><small>Offense</small></th></tr></thead><tbody><!--[-->`);
        ssrRenderList(__props.violation.filter((v) => v.vehicleID === tc.id), (vl, index2) => {
          var _a;
          _push(`<tr><td class="p-1">`);
          _push(ssrRenderComponent(_component_iconify_icon, {
            icon: "lets-icons:road-finish-duotone",
            class: "me-2 text-danger",
            width: "20",
            height: "20"
          }, null, _parent));
          _push(`<small>${ssrInterpolate(((_a = vl.violations) == null ? void 0 : _a.violation) || "Unknown Violation")}</small></td><td class="p-1"><small>${ssrInterpolate(formatOffense(vl.offense || 0))}</small></td></tr>`);
        });
        _push(`<!--]--></tbody></table><div class="text-danger fw-bold fs-6"> On: ${ssrInterpolate(formatDate(tc.created_at))}</div></td><td class="text-wrap"><div>${ssrInterpolate(tc.vehicle)}</div><div class="fw-bold">${ssrInterpolate(tc.plateNumber)}</div></td><td><p>${ssrInterpolate(tc.IDnumber != null ? tc.IDnumber : "None")}</p></td></tr>`);
      });
      _push(`<!--]--></tbody></table></div></div></div></div></div></div>`);
      _push(ssrRenderComponent(Footer, null, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/User/Ticket-History.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
