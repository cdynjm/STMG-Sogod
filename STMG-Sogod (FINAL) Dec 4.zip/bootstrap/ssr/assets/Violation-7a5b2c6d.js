import { ref, onMounted, mergeProps, unref, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrRenderList } from "vue/server-renderer";
import { useForm } from "@inertiajs/vue3";
import { _ as _sfc_main$1, a as _sfc_main$2 } from "./Sidebar-471d4597.js";
import { F as Footer } from "./Footer-7a30cc67.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
Swal.mixin({
  customClass: {
    confirmButton: "btn btn-danger",
    cancelButton: "btn btn-secondary"
  },
  buttonsStyling: false
});
const _sfc_main = {
  __name: "Violation",
  __ssrInlineRender: true,
  props: {
    violation: Array,
    auth: Array
  },
  setup(__props) {
    const successToast = ref(null);
    const label = useForm({ response: null });
    const createModal = ref(null);
    const editModal = ref(null);
    onMounted(() => {
      createModal.value = new bootstrap.Modal($("#createModal"), {
        keyboard: false
      });
      editModal.value = new bootstrap.Modal($("#editModal"), {
        keyboard: false
      });
      successToast.value = new bootstrap.Toast($("#success-toast"), {
        keyboard: false
      });
    });
    const createForm = useForm({
      violation: null,
      fee: null,
      error: null,
      status: null
    });
    const editForm = useForm({
      id: null,
      violation: null,
      fee: null,
      error: null,
      status: null
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "wrapper" }, _attrs))}>`);
      _push(ssrRenderComponent(_sfc_main$1, { page: "Violations" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, null, null, _parent));
      _push(`<div class="toast-container position-fixed top-0 start-50 translate-middle-x p-4"><div id="success-toast" class="toast" role="alert" aria-live="assertive" aria-atomic="true"><div class="toast-header"><div class="auth-logo me-auto"><span class="fs-4 fw-bold"> Done </span></div><small class="text-success fs-4"><i class="fa-solid fa-circle-check"></i></small><button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button></div><div class="toast-body">${ssrInterpolate(unref(label).response)}</div></div></div><div class="modal fade" id="createModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><h5 class="modal-title" id="staticBackdropLabel">Create Violation</h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><form action=""><div class="modal-body">`);
      if (unref(createForm).error) {
        _push(`<div class="alert alert-danger">${ssrInterpolate(unref(createForm).error)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<label for="" class="mb-1">Violation Name</label><input type="text" class="form-control mb-3"${ssrRenderAttr("value", unref(createForm).violation)} required></div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button><button type="" class="btn btn-primary">Save</button></div></form></div></div></div><div class="modal fade" id="editModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><h5 class="modal-title" id="staticBackdropLabel">Edit Violation</h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><form action=""><div class="modal-body">`);
      if (unref(editForm).error) {
        _push(`<div class="alert alert-danger">${ssrInterpolate(unref(editForm).error)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<input type="hidden" class="form-control"${ssrRenderAttr("value", unref(editForm).id)}><label for="" class="mb-1">Violation Name</label><input type="text" class="form-control mb-3"${ssrRenderAttr("value", unref(editForm).violation)} required></div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button><button type="" class="btn btn-primary">Save</button></div></form></div></div></div><div class="page-content"><div class="container-fluid"><div class="row"><div class="col-md-12"><div class="card"><div class="card-header"><div class="d-flex justify-content-between align-items-center"><h6 class="fw-bold">List of Violations</h6><button class="btn btn-primary shadow-lg btn-sm"> + Add</button></div></div><div class="card-body"><div class="table-responsive"><table class="table table-hover text-nowrap"><thead><tr class="fs-6"><th>No.</th><th>Violations</th><th>Action</th></tr></thead><tbody><!--[-->`);
      ssrRenderList(__props.violation, (vl, index) => {
        _push(`<tr><td>${ssrInterpolate(index + 1)}</td><td>${ssrInterpolate(vl.violation)}</td><td><a href="#" class="me-2"><i class="fa-solid fa-pencil"></i></a><a href="#" class=""><i class="fa-solid fa-trash"></i></a></td></tr>`);
      });
      _push(`<!--]--></tbody></table></div></div></div></div></div></div>`);
      _push(ssrRenderComponent(Footer, null, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Violation.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
