<template>
    <div class="row">
        <div class="col-lg-12">
            <div class="text-center p-4">
                <div class="col-12 d-flex align-items-center justify-content-center">
                    <!-- Sogod logo on the left side of the labels -->
                    <div class="me-1">
                        <a href="https://www.sogodlgu.gov.ph/" target="_blank">
                            <img src="/logo/logo-sogod.gif" class="rounded-circle" style="width: 50px;" alt="Sogod Logo">
                        </a>
                    </div>

                    <!-- Text labels to the right of the logo -->
                    <div>
                        <p class="text-sm text-secondary mb-0">STMG - Road Traffic Offense IMS</p>
                        <p class="fw-bolder text-sm mb-0">Sogod Southern Leyte</p>
                        <small>Developed By: Capstone Project Group</small>
                    </div>

                    <div class="ms-1">
                        <a href="https://www.sogodlgu.gov.ph/" target="_blank">
                            <img src="/logo/stmg-logo.jpg" class="rounded-circle" style="width: 50px;" alt="Sogod Logo">
                        </a>
                    </div>
                </div>
                <hr class="mt-2 mx-5">
            </div>
        </div>
    </div>
</template>
